public class Post {

    String data;
    String hora;
    String conteudo;

    public Post(String d, String h, String c) {
        this.data = d;
        this.hora = h;
        this.conteudo = c;
    }
}
